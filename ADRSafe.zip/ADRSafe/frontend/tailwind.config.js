// tailwind.config.js
module.exports = {
    // ...
    variants: {
      extend: {
        stroke: ['peer-checked'],
      },
    },
  }